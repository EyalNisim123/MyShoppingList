﻿using ConnectedServices;
using IT_Template;
using Microsoft.Data.SqlClient;
using MyShoppingList.BL.Entities;
using System.Collections.Generic;
using System.Data;


namespace IT_Template.DAL
{
    public static class clsDal
    {
        //אם הנתונים היו חוזרים מבסיס נתונים הפונקציה הייתה מסוג ASYNC
        public static ShoppingList GetShoppingList()
        {
            return new ShoppingList { ShoppingListItem = GetMockItem() };
        }

        public static List<GroseryItem> GetMockItem()
        {
            List<GroseryItem> ListGroseryItem = new List<GroseryItem>();

            ListGroseryItem.Add(new GroseryItem { GroseryItemId = 1, GroseryItemName = "Tomatos", GroseryItemPrice = 5, GroseryPriceId = "NIS", Description = "Hey Im Tomatos Desc" });
            ListGroseryItem.Add(new GroseryItem { GroseryItemId = 2, GroseryItemName = "Cucombers", GroseryItemPrice = 3, GroseryPriceId = "NIS", Description = "Hey Im Cucombers Desc" });
            ListGroseryItem.Add(new GroseryItem { GroseryItemId = 3, GroseryItemName = "Bread", GroseryItemPrice = 10, GroseryPriceId = "NIS", Description = "Hey Im Bread Desc" });
            ListGroseryItem.Add(new GroseryItem { GroseryItemId = 4, GroseryItemName = "Grapes", GroseryItemPrice = 4, GroseryPriceId = "NIS", Description = "Hey Im Grapes Desc" });

            return ListGroseryItem;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MyShoppingList.BL.Entities
{
    public class ShoppingList
    {
        public List<GroseryItem> ShoppingListItem { get; set; }
    }
}

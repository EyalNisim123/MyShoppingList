﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MyShoppingList.BL.Entities
{
    public class GroseryItem
    {
        public int GroseryItemId { get; set; }
        public string GroseryItemName { get; set; }
        public float GroseryItemPrice { get; set; }
        public string GroseryPriceId { get; set; }
        public string Description { get; set; }
    }
}

public enum GroseryPriceType
{
    NIS,
    DOLAR,
    EURO
}
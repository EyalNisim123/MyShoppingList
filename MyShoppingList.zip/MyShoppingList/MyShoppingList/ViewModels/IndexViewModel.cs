﻿using ConnectedServices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Template_MVC_Vue.ViewModels
{
    public class IndexViewModel
    {
        public int bla { get; set; }
    }
}

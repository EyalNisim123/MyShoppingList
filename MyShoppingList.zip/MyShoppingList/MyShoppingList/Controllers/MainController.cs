﻿using ConnectedServices;
using IT_Template;
using IT_Template.DAL;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MyShoppingList.BL.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MyShoppingList.Controllers
{
    [ApiController]
    public class MainController : ControllerBase
    {

        [HttpPost, Route("GetShoppingList")]
        public ShoppingList GetShoppingList()
        {
            try
            {
                return clsDal.GetShoppingList();
            }
            catch (Exception ex)
            {
                Helpers.WriteErorr("128....", ex.Message, ex.StackTrace);
                return new ShoppingList { };
            }
        }

    }
}

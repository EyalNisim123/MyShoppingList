﻿using IT_Template;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Threading.Tasks;
using Template_MVC_Vue.ViewModels;


namespace Template_MVC_Vue.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public async Task<IActionResult> Index()
        {
            IndexViewModel indexViewModel = new IndexViewModel
            {
                bla = 1
            };
            await Task.Delay(1);
            return View(indexViewModel);
        }
    }
}

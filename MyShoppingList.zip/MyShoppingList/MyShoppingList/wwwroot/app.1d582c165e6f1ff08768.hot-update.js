webpackHotUpdate("app",{

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"46b12186-vue-loader-template\"}!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/MainShoppingList.vue?vue&type=template&id=07975f2f&scoped=true&":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"46b12186-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/MainShoppingList.vue?vue&type=template&id=07975f2f&scoped=true& ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "v-card",
    [
      _c(
        "v-form",
        { ref: "form", attrs: { "lazy-validation": "" } },
        [
          _c(
            "v-toolbar",
            {
              staticStyle: { "box-shadow": "none", "margin-bottom": "10px" },
              attrs: { dense: "", color: "transparent" }
            },
            [
              _c(
                "v-toolbar-title",
                {
                  staticStyle: {
                    flex: "1",
                    display: "flex",
                    "justify-content": "flex-end",
                    "text-align": "center",
                    "margin-bottom": "-10px"
                  }
                },
                [
                  _c(
                    "div",
                    { staticStyle: { "margin-left": "40px" } },
                    [
                      _c(
                        "v-icon",
                        {
                          attrs: { color: "rgb(22, 58, 88)" },
                          on: { click: _vm.btnAddNewProduct }
                        },
                        [_vm._v("mdi-folder-plus")]
                      ),
                      _c("h5", [_vm._v("Add Product")])
                    ],
                    1
                  )
                ]
              )
            ],
            1
          ),
          _c("div", { staticStyle: { display: "flex" } }, [
            _c(
              "div",
              { staticStyle: { flex: "4" }, attrs: { id: "scroll" } },
              [
                _c(
                  "v-card",
                  { staticClass: "card-settings" },
                  _vm._l(_vm.Items, function(value, n) {
                    return _c("ItemCard", {
                      key: n,
                      staticStyle: { margin: "20px", display: "flex" },
                      attrs: { ItemRow: value, Favorite: true }
                    })
                  }),
                  1
                )
              ],
              1
            ),
            _c(
              "div",
              {
                staticStyle: { flex: "1", direction: "ltr" },
                attrs: { id: "scroll" }
              },
              [
                _c("v-card", { staticClass: "card-total" }, [
                  _c("p", [
                    _vm._v("Total Product: " + _vm._s(_vm.Items.length))
                  ]),
                  _c("p", [_vm._v("Total Price: " + _vm._s(_vm.TotalPrice))])
                ])
              ],
              1
            )
          ]),
          _c(
            "div",
            [
              _c(
                "v-dialog",
                {
                  attrs: { persistent: "", "max-width": "600px" },
                  model: {
                    value: _vm.AddNewProductDialog,
                    callback: function($$v) {
                      _vm.AddNewProductDialog = $$v
                    },
                    expression: "AddNewProductDialog"
                  }
                },
                [
                  _c(
                    "v-card",
                    [
                      _c("v-card-title", [
                        _c("span", { staticClass: "text-h5" }, [
                          _vm._v(_vm._s(_vm.AddOrEdit))
                        ])
                      ]),
                      _c(
                        "v-card-text",
                        [
                          _c(
                            "v-container",
                            [
                              _c(
                                "v-row",
                                [
                                  _c(
                                    "v-col",
                                    { attrs: { cols: "12", sm: "6", md: "4" } },
                                    [
                                      _c("v-text-field", {
                                        directives: [
                                          {
                                            name: "mode",
                                            rawName: "v-mode",
                                            value: _vm.newRow.GroseryItemName,
                                            expression: "newRow.GroseryItemName"
                                          }
                                        ],
                                        attrs: {
                                          rules: [_vm.rules.required],
                                          label: "Name",
                                          required: ""
                                        }
                                      })
                                    ],
                                    1
                                  ),
                                  _c(
                                    "v-col",
                                    { attrs: { cols: "12", sm: "6", md: "4" } },
                                    [
                                      _c("v-text-field", {
                                        directives: [
                                          {
                                            name: "mode",
                                            rawName: "v-mode",
                                            value: _vm.newRow.GroseryItemPrice,
                                            expression:
                                              "newRow.GroseryItemPrice"
                                          }
                                        ],
                                        attrs: {
                                          rules: [_vm.rules.required],
                                          label: "Price",
                                          required: ""
                                        },
                                        on: { keypress: _vm.onlyNumber }
                                      })
                                    ],
                                    1
                                  )
                                ],
                                1
                              ),
                              _c(
                                "v-row",
                                [
                                  _c(
                                    "v-col",
                                    { attrs: { cols: "12" } },
                                    [
                                      _c("v-text-field", {
                                        directives: [
                                          {
                                            name: "mode",
                                            rawName: "v-mode",
                                            value: _vm.newRow.Description,
                                            expression: "newRow.Description"
                                          }
                                        ],
                                        attrs: {
                                          rules: [_vm.rules.required],
                                          label: "Decsriptoin",
                                          required: ""
                                        }
                                      })
                                    ],
                                    1
                                  )
                                ],
                                1
                              )
                            ],
                            1
                          )
                        ],
                        1
                      ),
                      _c(
                        "v-card-actions",
                        [
                          _c("v-spacer"),
                          _c(
                            "v-btn",
                            {
                              attrs: { color: "blue darken-1", text: "" },
                              on: {
                                click: function($event) {
                                  _vm.AddNewProductDialog = false
                                }
                              }
                            },
                            [_vm._v(" Close ")]
                          ),
                          _c(
                            "v-btn",
                            {
                              directives: [
                                {
                                  name: "show",
                                  rawName: "v-show",
                                  value: _vm.SaveOrEdit,
                                  expression: "SaveOrEdit"
                                }
                              ],
                              attrs: { color: "blue darken-1", text: "" },
                              on: { click: _vm.SaveProduct }
                            },
                            [_vm._v(" Save ")]
                          ),
                          _c(
                            "v-btn",
                            {
                              directives: [
                                {
                                  name: "show",
                                  rawName: "v-show",
                                  value: !_vm.SaveOrEdit,
                                  expression: "!SaveOrEdit"
                                }
                              ],
                              attrs: { color: "blue darken-1", text: "" },
                              on: { click: _vm.EditProduct }
                            },
                            [_vm._v(" Edit ")]
                          )
                        ],
                        1
                      )
                    ],
                    1
                  )
                ],
                1
              )
            ],
            1
          )
        ],
        1
      ),
      _c(
        "v-progress-circular",
        {
          directives: [
            {
              name: "show",
              rawName: "v-show",
              value: _vm.value,
              expression: "value"
            }
          ],
          staticStyle: {
            opacity: "0.5",
            "background-color": "black",
            height: "96%",
            width: "100% !important",
            position: "fixed",
            "z-index": "999999999999999999",
            top: "0vh",
            right: "0vw"
          },
          attrs: { size: 350, width: 20, color: "primary", indeterminate: "" }
        },
        [
          _c(
            "p",
            { staticStyle: { "font-size": "30px", "font-weight": "bold" } },
            [_vm._v(" אנא המתן...... ")]
          )
        ]
      ),
      _vm.alert
        ? _c(
            "v-alert",
            {
              staticStyle: { "z-index": "999", position: "fixed", bottom: "0" },
              attrs: { prominent: "", type: _vm.msgType }
            },
            [_vm._v(_vm._s(_vm.msg))]
          )
        : _vm._e()
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ })

})
//# sourceMappingURL=app.1d582c165e6f1ff08768.hot-update.js.map
webpackHotUpdate("app",{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/MainShoppingList.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--12-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/MainShoppingList.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ItemCard_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ItemCard.vue */ "./src/components/ItemCard.vue");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


var BackendUrl = window.location.origin;
var api = axios__WEBPACK_IMPORTED_MODULE_1___default.a.create({
  baseURL: BackendUrl,
  headers: {
    'Content-Type': 'application/json'
  }
});
/* harmony default export */ __webpack_exports__["default"] = ({
  name: "MainShoppingList",
  components: {
    ItemCard: _ItemCard_vue__WEBPACK_IMPORTED_MODULE_0__["default"]
  },
  data: function data() {
    return {
      Items: [],
      TotalPrice: 0,
      value: false,
      AddNewProductDialog: false,
      msgType: null,
      alert: false,
      msg: ''
    };
  },
  watch: {
    Items: function Items() {
      this.SumOfProduct();
    }
  },
  methods: {
    SumOfProduct: function SumOfProduct() {
      if (this.Items.length > 0) {
        for (var i = 0; i < this.Items.length; i++) {
          this.TotalPrice = parseFloat(this.TotalPrice) + parseFloat(this.Items[i].GroseryItemPrice);
        }
      } else {
        return 0;
      }
    },
    GetShoppingList: function GetShoppingList() {
      var _this = this;

      this.value = true;
      api.post("/GetShoppingList").then(function (response) {
        if (response.data) {
          _this.Items = response.data.ShoppingListItem;
          _this.value = false;
        }
      }, function (err) {
        var _this2 = this;

        this.value = false;
        this.msgType = 'error';
        this.alert = true;
        this.msg = 'Error';
        setTimeout(function () {
          _this2.alert = false;
        }, 1500);
        console.log(err);
      });
    },
    btnAddNewProduct: function btnAddNewProduct() {
      this.AddNewProductDialog = true;
    },
    SaveProduct: function SaveProduct() {
      var x = 1;
    },
    EditProduct: function EditProduct() {
      var x = 1;
    }
  },
  mounted: function mounted() {
    this.GetShoppingList();
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"46b12186-vue-loader-template\"}!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/MainShoppingList.vue?vue&type=template&id=07975f2f&scoped=true&":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"46b12186-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/MainShoppingList.vue?vue&type=template&id=07975f2f&scoped=true& ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "v-card",
    [
      _c(
        "v-form",
        { ref: "form", attrs: { "lazy-validation": "" } },
        [
          _c(
            "v-toolbar",
            {
              staticStyle: { "box-shadow": "none", "margin-bottom": "10px" },
              attrs: { dense: "", color: "transparent" }
            },
            [
              _c(
                "v-toolbar-title",
                {
                  staticStyle: {
                    flex: "1",
                    display: "flex",
                    "justify-content": "flex-end",
                    "text-align": "center",
                    "margin-bottom": "-10px"
                  }
                },
                [
                  _c(
                    "div",
                    { staticStyle: { "margin-left": "40px" } },
                    [
                      _c(
                        "v-icon",
                        {
                          attrs: { color: "rgb(22, 58, 88)" },
                          on: { click: _vm.btnAddNewProduct }
                        },
                        [_vm._v("mdi-folder-plus")]
                      ),
                      _c("h5", [_vm._v("Add Product")])
                    ],
                    1
                  )
                ]
              )
            ],
            1
          ),
          _c("div", { staticStyle: { display: "flex" } }, [
            _c(
              "div",
              { staticStyle: { flex: "4" }, attrs: { id: "scroll" } },
              [
                _c(
                  "v-card",
                  { staticClass: "card-settings" },
                  _vm._l(_vm.Items, function(value, n) {
                    return _c("ItemCard", {
                      key: n,
                      staticStyle: { margin: "20px", display: "flex" },
                      attrs: { ItemRow: value, Favorite: true }
                    })
                  }),
                  1
                )
              ],
              1
            ),
            _c(
              "div",
              {
                staticStyle: { flex: "1", direction: "ltr" },
                attrs: { id: "scroll" }
              },
              [
                _c("v-card", { staticClass: "card-total" }, [
                  _c("p", [
                    _vm._v("Total Product: " + _vm._s(_vm.Items.length))
                  ]),
                  _c("p", [_vm._v("Total Price: " + _vm._s(_vm.TotalPrice))])
                ])
              ],
              1
            )
          ]),
          _c(
            "div",
            [
              _c(
                "v-dialog",
                {
                  attrs: { persistent: "", "max-width": "600px" },
                  model: {
                    value: _vm.AddNewProductDialog,
                    callback: function($$v) {
                      _vm.AddNewProductDialog = $$v
                    },
                    expression: "AddNewProductDialog"
                  }
                },
                [
                  _c(
                    "v-card",
                    [
                      _c("v-card-title", [
                        _c("span", { staticClass: "text-h5" }, [
                          _vm._v(_vm._s(_vm.AddOrEdit))
                        ])
                      ]),
                      _c(
                        "v-card-text",
                        [
                          _c(
                            "v-container",
                            [
                              _c(
                                "v-row",
                                [
                                  _c(
                                    "v-col",
                                    { attrs: { cols: "12", sm: "6", md: "4" } },
                                    [
                                      _c("v-text-field", {
                                        attrs: { label: "Name", required: "" }
                                      })
                                    ],
                                    1
                                  ),
                                  _c(
                                    "v-col",
                                    { attrs: { cols: "12", sm: "6", md: "4" } },
                                    [
                                      _c("v-text-field", {
                                        attrs: { label: "Price", required: "" }
                                      })
                                    ],
                                    1
                                  ),
                                  _c(
                                    "v-col",
                                    { attrs: { cols: "12", sm: "6", md: "4" } },
                                    [
                                      _c("v-text-field", {
                                        attrs: {
                                          label: "Decsriptoin",
                                          required: ""
                                        }
                                      })
                                    ],
                                    1
                                  )
                                ],
                                1
                              )
                            ],
                            1
                          )
                        ],
                        1
                      ),
                      _c(
                        "v-card-actions",
                        [
                          _c("v-spacer"),
                          _c(
                            "v-btn",
                            {
                              attrs: { color: "blue darken-1", text: "" },
                              on: {
                                click: function($event) {
                                  _vm.AddNewProductDialog = false
                                }
                              }
                            },
                            [_vm._v(" Close ")]
                          ),
                          _c(
                            "v-btn",
                            {
                              attrs: { color: "blue darken-1", text: "" },
                              on: { click: _vm.SaveProduct }
                            },
                            [_vm._v(" Save ")]
                          ),
                          _c(
                            "v-btn",
                            {
                              attrs: { color: "blue darken-1", text: "" },
                              on: { click: _vm.EditProduct }
                            },
                            [_vm._v(" Edit ")]
                          )
                        ],
                        1
                      )
                    ],
                    1
                  )
                ],
                1
              )
            ],
            1
          )
        ],
        1
      ),
      _c(
        "v-progress-circular",
        {
          directives: [
            {
              name: "show",
              rawName: "v-show",
              value: _vm.value,
              expression: "value"
            }
          ],
          staticStyle: {
            opacity: "0.5",
            "background-color": "black",
            height: "96%",
            width: "100% !important",
            position: "fixed",
            "z-index": "999999999999999999",
            top: "0vh",
            right: "0vw"
          },
          attrs: { size: 350, width: 20, color: "primary", indeterminate: "" }
        },
        [
          _c(
            "p",
            { staticStyle: { "font-size": "30px", "font-weight": "bold" } },
            [_vm._v(" אנא המתן...... ")]
          )
        ]
      ),
      _vm.alert
        ? _c(
            "v-alert",
            {
              staticStyle: { "z-index": "999", position: "fixed", bottom: "0" },
              attrs: { prominent: "", type: _vm.msgType }
            },
            [_vm._v(_vm._s(_vm.msg))]
          )
        : _vm._e()
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./src/components/MainShoppingList.vue":
/*!*********************************************!*\
  !*** ./src/components/MainShoppingList.vue ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _MainShoppingList_vue_vue_type_template_id_07975f2f_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./MainShoppingList.vue?vue&type=template&id=07975f2f&scoped=true& */ "./src/components/MainShoppingList.vue?vue&type=template&id=07975f2f&scoped=true&");
/* harmony import */ var _MainShoppingList_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./MainShoppingList.vue?vue&type=script&lang=js& */ "./src/components/MainShoppingList.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _MainShoppingList_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./MainShoppingList.vue?vue&type=style&index=0&lang=css& */ "./src/components/MainShoppingList.vue?vue&type=style&index=0&lang=css&");
/* harmony import */ var _MainShoppingList_vue_vue_type_style_index_1_id_07975f2f_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./MainShoppingList.vue?vue&type=style&index=1&id=07975f2f&scoped=true&lang=css& */ "./src/components/MainShoppingList.vue?vue&type=style&index=1&id=07975f2f&scoped=true&lang=css&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");
/* harmony import */ var _node_modules_vuetify_loader_lib_runtime_installComponents_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../node_modules/vuetify-loader/lib/runtime/installComponents.js */ "./node_modules/vuetify-loader/lib/runtime/installComponents.js");
/* harmony import */ var _node_modules_vuetify_loader_lib_runtime_installComponents_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vuetify_loader_lib_runtime_installComponents_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var vuetify_lib_components_VAlert__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! vuetify/lib/components/VAlert */ "./node_modules/vuetify/lib/components/VAlert/index.js");
/* harmony import */ var vuetify_lib_components_VBtn__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! vuetify/lib/components/VBtn */ "./node_modules/vuetify/lib/components/VBtn/index.js");
/* harmony import */ var vuetify_lib_components_VCard__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! vuetify/lib/components/VCard */ "./node_modules/vuetify/lib/components/VCard/index.js");
/* harmony import */ var vuetify_lib_components_VGrid__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! vuetify/lib/components/VGrid */ "./node_modules/vuetify/lib/components/VGrid/index.js");
/* harmony import */ var vuetify_lib_components_VDialog__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! vuetify/lib/components/VDialog */ "./node_modules/vuetify/lib/components/VDialog/index.js");
/* harmony import */ var vuetify_lib_components_VForm__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! vuetify/lib/components/VForm */ "./node_modules/vuetify/lib/components/VForm/index.js");
/* harmony import */ var vuetify_lib_components_VIcon__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! vuetify/lib/components/VIcon */ "./node_modules/vuetify/lib/components/VIcon/index.js");
/* harmony import */ var vuetify_lib_components_VProgressCircular__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! vuetify/lib/components/VProgressCircular */ "./node_modules/vuetify/lib/components/VProgressCircular/index.js");
/* harmony import */ var vuetify_lib_components_VTextField__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! vuetify/lib/components/VTextField */ "./node_modules/vuetify/lib/components/VTextField/index.js");
/* harmony import */ var vuetify_lib_components_VToolbar__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! vuetify/lib/components/VToolbar */ "./node_modules/vuetify/lib/components/VToolbar/index.js");







/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_4__["default"])(
  _MainShoppingList_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _MainShoppingList_vue_vue_type_template_id_07975f2f_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"],
  _MainShoppingList_vue_vue_type_template_id_07975f2f_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "07975f2f",
  null
  
)

/* vuetify-loader */


















_node_modules_vuetify_loader_lib_runtime_installComponents_js__WEBPACK_IMPORTED_MODULE_5___default()(component, {VAlert: vuetify_lib_components_VAlert__WEBPACK_IMPORTED_MODULE_6__["VAlert"],VBtn: vuetify_lib_components_VBtn__WEBPACK_IMPORTED_MODULE_7__["VBtn"],VCard: vuetify_lib_components_VCard__WEBPACK_IMPORTED_MODULE_8__["VCard"],VCardActions: vuetify_lib_components_VCard__WEBPACK_IMPORTED_MODULE_8__["VCardActions"],VCardText: vuetify_lib_components_VCard__WEBPACK_IMPORTED_MODULE_8__["VCardText"],VCardTitle: vuetify_lib_components_VCard__WEBPACK_IMPORTED_MODULE_8__["VCardTitle"],VCol: vuetify_lib_components_VGrid__WEBPACK_IMPORTED_MODULE_9__["VCol"],VContainer: vuetify_lib_components_VGrid__WEBPACK_IMPORTED_MODULE_9__["VContainer"],VDialog: vuetify_lib_components_VDialog__WEBPACK_IMPORTED_MODULE_10__["VDialog"],VForm: vuetify_lib_components_VForm__WEBPACK_IMPORTED_MODULE_11__["VForm"],VIcon: vuetify_lib_components_VIcon__WEBPACK_IMPORTED_MODULE_12__["VIcon"],VProgressCircular: vuetify_lib_components_VProgressCircular__WEBPACK_IMPORTED_MODULE_13__["VProgressCircular"],VRow: vuetify_lib_components_VGrid__WEBPACK_IMPORTED_MODULE_9__["VRow"],VSpacer: vuetify_lib_components_VGrid__WEBPACK_IMPORTED_MODULE_9__["VSpacer"],VTextField: vuetify_lib_components_VTextField__WEBPACK_IMPORTED_MODULE_14__["VTextField"],VToolbar: vuetify_lib_components_VToolbar__WEBPACK_IMPORTED_MODULE_15__["VToolbar"],VToolbarTitle: vuetify_lib_components_VToolbar__WEBPACK_IMPORTED_MODULE_15__["VToolbarTitle"]})


/* hot reload */
if (true) {
  var api = __webpack_require__(/*! ./node_modules/vue-hot-reload-api/dist/index.js */ "./node_modules/vue-hot-reload-api/dist/index.js")
  api.install(__webpack_require__(/*! vue */ "./node_modules/vue/dist/vue.runtime.esm.js"))
  if (api.compatible) {
    module.hot.accept()
    if (!api.isRecorded('07975f2f')) {
      api.createRecord('07975f2f', component.options)
    } else {
      api.reload('07975f2f', component.options)
    }
    module.hot.accept(/*! ./MainShoppingList.vue?vue&type=template&id=07975f2f&scoped=true& */ "./src/components/MainShoppingList.vue?vue&type=template&id=07975f2f&scoped=true&", function(__WEBPACK_OUTDATED_DEPENDENCIES__) { /* harmony import */ _MainShoppingList_vue_vue_type_template_id_07975f2f_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./MainShoppingList.vue?vue&type=template&id=07975f2f&scoped=true& */ "./src/components/MainShoppingList.vue?vue&type=template&id=07975f2f&scoped=true&");
(function () {
      api.rerender('07975f2f', {
        render: _MainShoppingList_vue_vue_type_template_id_07975f2f_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"],
        staticRenderFns: _MainShoppingList_vue_vue_type_template_id_07975f2f_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]
      })
    })(__WEBPACK_OUTDATED_DEPENDENCIES__); }.bind(this))
  }
}
component.options.__file = "src/components/MainShoppingList.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ })

})
//# sourceMappingURL=app.a1e3a4d990606d0cb5b7.hot-update.js.map
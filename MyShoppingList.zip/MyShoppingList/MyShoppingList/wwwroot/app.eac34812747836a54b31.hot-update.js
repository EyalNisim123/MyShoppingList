webpackHotUpdate("app",{

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"46b12186-vue-loader-template\"}!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/MainShoppingList.vue?vue&type=template&id=07975f2f&scoped=true&":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"46b12186-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/MainShoppingList.vue?vue&type=template&id=07975f2f&scoped=true& ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "v-card",
    [
      _c(
        "v-form",
        { ref: "form", attrs: { "lazy-validation": "" } },
        [
          _c(
            "v-toolbar",
            {
              staticStyle: { "box-shadow": "none", "margin-bottom": "10px" },
              attrs: { dense: "", color: "transparent" }
            },
            [
              _c(
                "v-toolbar-title",
                {
                  staticStyle: {
                    flex: "1",
                    display: "flex",
                    "justify-content": "flex-end",
                    "text-align": "center",
                    "margin-bottom": "-10px"
                  }
                },
                [
                  _c(
                    "div",
                    { staticStyle: { "margin-left": "40px" } },
                    [
                      _c(
                        "v-icon",
                        {
                          attrs: { color: "rgb(22, 58, 88)" },
                          on: { click: _vm.btnAAddNewProduct }
                        },
                        [_vm._v("mdi-folder-plus")]
                      ),
                      _c("h5", [_vm._v("Add Product")])
                    ],
                    1
                  )
                ]
              )
            ],
            1
          ),
          _c("div", { staticStyle: { display: "flex" } }, [
            _c(
              "div",
              { attrs: { id: "scroll" } },
              [
                _c(
                  "v-card",
                  { staticClass: "card-settings" },
                  _vm._l(_vm.Items, function(value, n) {
                    return _c("ItemCard", {
                      key: n,
                      staticStyle: { margin: "20px", display: "flex" },
                      attrs: { ItemRow: value, Favorite: true }
                    })
                  }),
                  1
                )
              ],
              1
            ),
            _c(
              "div",
              { attrs: { id: "scroll" } },
              [
                _c("v-card", { staticClass: "card-total" }, [
                  _c("p", [_vm._v("Total Product")]),
                  _c("p", [_vm._v("Total Price")])
                ])
              ],
              1
            )
          ])
        ],
        1
      ),
      _c(
        "v-progress-circular",
        {
          directives: [
            {
              name: "show",
              rawName: "v-show",
              value: _vm.value,
              expression: "value"
            }
          ],
          staticStyle: {
            opacity: "0.5",
            "background-color": "black",
            height: "96%",
            width: "100% !important",
            position: "fixed",
            "z-index": "999999999999999999",
            top: "0vh",
            right: "0vw"
          },
          attrs: { size: 350, width: 20, color: "primary", indeterminate: "" }
        },
        [
          _c(
            "p",
            { staticStyle: { "font-size": "30px", "font-weight": "bold" } },
            [_vm._v(" אנא המתן...... ")]
          )
        ]
      ),
      _vm.alert
        ? _c(
            "v-alert",
            {
              staticStyle: { "z-index": "999", position: "fixed", bottom: "0" },
              attrs: { prominent: "", type: _vm.msgType }
            },
            [_vm._v(_vm._s(_vm.msg))]
          )
        : _vm._e()
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ })

})
//# sourceMappingURL=app.eac34812747836a54b31.hot-update.js.map
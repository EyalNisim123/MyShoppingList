webpackHotUpdate("app",{

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/layout/Menu.vue?vue&type=style&index=0&lang=css&":
/*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--6-oneOf-1-1!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--6-oneOf-1-2!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/layout/Menu.vue?vue&type=style&index=0&lang=css& ***!
  \***************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\r\n\r\n/*\r\n\t.theme--dark.v-divider {\r\n\t\tborder-color: transparent !important;\r\n\t}\r\n\r\n\t.v-list-item {\r\n\t\tmin-height: 50px !important\r\n\t}\r\n\r\n\t.v-icon.v-icon {\r\n\t\tfont-size: 35px !important;\r\n\t}\r\n\r\n\t.v-list-item__icon {\r\n\t\tmargin-left: 7px !important;\r\n\t}\r\n\r\n\t.v-main {\r\n\t\theight: 90vh;\r\n\t}*/\r\n", ""]);
// Exports
module.exports = exports;


/***/ })

})
//# sourceMappingURL=app.2e381f57a13ef6e17330.hot-update.js.map
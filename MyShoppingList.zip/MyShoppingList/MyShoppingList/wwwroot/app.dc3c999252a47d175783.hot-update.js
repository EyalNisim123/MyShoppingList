webpackHotUpdate("app",{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/MainShoppingList.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--12-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/MainShoppingList.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//import ItemCard from './ItemCard.vue';

var BackendUrl = window.location.origin;
var api = axios__WEBPACK_IMPORTED_MODULE_0___default.a.create({
  baseURL: BackendUrl,
  headers: {
    'Content-Type': 'application/json'
  }
});
/* harmony default export */ __webpack_exports__["default"] = ({
  name: "MainShoppingList",
  //components: { ItemCard },
  data: function data() {
    return {
      Items: [],
      value: false,
      msgType: null,
      alert: false,
      msg: ''
    };
  },
  methods: {
    onlyNumber: function onlyNumber(event) {
      var keyCode = event.keyCode;

      if (keyCode >= 48 && keyCode <= 57 || keyCode == 44 || keyCode == 39) {
        var x = 1;
      } else {
        event.preventDefault();
      }
    },
    checkLengthPrice: function checkLengthPrice(event) {
      if (this.form.AdPrice) {
        if (this.form.AdPrice.length < 6 || event.keyCode == 8) {
          var x = 1;
        } else {
          event.preventDefault();
        }
      }
    },
    GetShoppingList: function GetShoppingList() {
      var _this = this;

      this.value = true;
      api.post("/GetShoppingList").then(function (response) {
        if (response.data) {
          _this.PatsTmp = response.data;
          _this.value = false;
        }
      }, function (err) {
        var _this2 = this;

        this.value = false;
        this.msgType = 'error';
        this.alert = true;
        this.msg = 'Error';
        setTimeout(function () {
          _this2.alert = false;
        }, 1500);
        console.log(err);
      });
    }
  },
  mounted: function mounted() {
    this.GetShoppingList();
  }
});

/***/ })

})
//# sourceMappingURL=app.dc3c999252a47d175783.hot-update.js.map
webpackHotUpdate("app",{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/ItemCard.vue?vue&type=script&lang=js&":
/*!*****************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--12-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/ItemCard.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//import PatsSheet from './PatsSheet.vue';
/* harmony default export */ __webpack_exports__["default"] = ({
  name: "ItemCard",
  //components: { PatsSheet },
  data: function data() {
    return {
      color: 'none',
      iconType: 'mdi-heart-outline',
      form: {},
      showPatsSheetModal: false,
      MainTitle: '',
      Price: '',
      SubTitle: '',
      SubSubTitle: '',
      colorDate: '#FFFFFF',
      dateTitle: '',
      AdFavorite: false,
      image: 'https://www.google.com/url?sa=i&url=https%3A%2F%2Fnaturopatia.org.il%2Fapple-and-honey%2F&psig=AOvVaw0QSzL70SfNGbp2xGicWW55&ust=1645781240921000&source=images&cd=vfe&ved=0CAsQjRxqFwoTCICN5YODmPYCFQAAAAAdAAAAABAD',
      imageCuontShow: false,
      iconImageType: 'mdi-numeric-2-box-multiple-outline'
    };
  },
  props: ['ItemRow', 'Favorite'],
  watch: {
    AdFavorite: function AdFavorite() {
      if (this.AdFavorite == true) {
        this.color = 'red';
        this.iconType = 'mdi-heart';
      } else {
        this.color = 'none';
        this.iconType = 'mdi-heart-outline';
      }
    }
  },
  methods: {
    btnFavorite: function btnFavorite() {
      if (this.AdFavorite == false) {
        this.color = 'red';
        this.iconType = 'mdi-heart';
        this.AdFavorite = true;
      } else {
        this.color = 'none';
        this.iconType = 'mdi-heart-outline';
        this.AdFavorite = false;
      }
    },
    //btnOpenAd() {
    //    if (this.showPatsSheetModal == false) {
    //        setTimeout(() => {
    //            if (this.$refs.child) {
    //                this.$refs.child.reloadItem();
    //            }
    //            this.showPatsSheetModal = true;
    //        }, 100);
    //    }
    //},
    closeDialogPatsSheetModal: function closeDialogPatsSheetModal() {
      this.showPatsSheetModal = false;
    }
  },
  mounted: function mounted() {}
});

/***/ })

})
//# sourceMappingURL=app.a6c4279c2171af7a0308.hot-update.js.map
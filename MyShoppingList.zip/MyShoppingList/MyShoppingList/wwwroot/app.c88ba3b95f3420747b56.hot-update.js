webpackHotUpdate("app",{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/MainShoppingList.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--12-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/MainShoppingList.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.find-index.js */ "./node_modules/core-js/modules/es.array.find-index.js");
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.splice.js */ "./node_modules/core-js/modules/es.array.splice.js");
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ItemCard_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./ItemCard.vue */ "./src/components/ItemCard.vue");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_3__);


//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


var BackendUrl = window.location.origin;
var api = axios__WEBPACK_IMPORTED_MODULE_3___default.a.create({
  baseURL: BackendUrl,
  headers: {
    'Content-Type': 'application/json'
  }
});
/* harmony default export */ __webpack_exports__["default"] = ({
  name: "MainShoppingList",
  components: {
    ItemCard: _ItemCard_vue__WEBPACK_IMPORTED_MODULE_2__["default"]
  },
  data: function data() {
    return {
      Items: [],
      ItemsTmp: [],
      newRow: {},
      TotalPrice: 0,
      value: false,
      SaveOrEdit: false,
      AddNewProductDialog: false,
      msgType: null,
      alert: false,
      AddOrEdit: 'New Product',
      msg: '',
      rules: {
        required: function required(v) {
          return !!v || 'Required';
        }
      }
    };
  },
  watch: {
    Items: function Items() {
      this.SumOfProduct();
    }
  },
  methods: {
    SumOfProduct: function SumOfProduct() {
      this.TotalPrice = 0;

      if (this.Items.length > 0) {
        for (var i = 0; i < this.Items.length; i++) {
          this.TotalPrice = parseFloat(this.TotalPrice) + parseFloat(this.Items[i].GroseryItemPrice);
        }
      } else {
        return 0;
      }
    },
    GetShoppingList: function GetShoppingList() {
      var _this = this;

      this.value = true;
      api.post("/GetShoppingList").then(function (response) {
        if (response.data) {
          _this.Items = response.data.ShoppingListItem;
          _this.value = false;
        }
      }, function (err) {
        this.value = false;
        this.ShowMessage('Error', 'error');
        console.log(err);
      });
    },
    btnAddNewProduct: function btnAddNewProduct() {
      this.AddNewProductDialog = true;
      this.SaveOrEdit = true;
      this.AddOrEdit = 'New Product';
      this.newRow = {};
    },
    SaveProduct: function SaveProduct() {
      if (this.$refs.formAddOrEdit.validate()) {
        this.newRow.GroseryItemId = this.Items.length + 1;
        this.newRow.GroseryPriceId = 'NIS';
        this.newRow.GroseryItemPrice = parseFloat(this.newRow.GroseryItemPrice);
        this.Items.push(this.newRow);
        this.AddNewProductDialog = false;
      } else {
        this.ShowMessage('Required Fields', 'error');
      }
    },
    ShowMessage: function ShowMessage(msg, type) {
      var _this2 = this;

      this.msgType = msg;
      this.alert = true;
      this.msg = type;
      setTimeout(function () {
        _this2.alert = false;
      }, 1500);
    },
    onlyNumber: function onlyNumber(event) {
      var keyCode = event.keyCode;

      if (keyCode >= 48 && keyCode <= 57 || keyCode == 44) {
        return;
      }

      event.preventDefault();
    },
    btnDelete: function btnDelete(id) {
      var vm = this;
      var index = this.Items.findIndex(function (e) {
        return e.GroseryItemId === id;
      });
      this.Items.splice(index, 1);
      this.ItemsTmp = Object.assign(this.ItemsTmp, this.Items);
      this.Items = [];
      setTimeout(function () {
        vm.Items = vm.ItemsTmp;
        vm.SumOfProduct();
      }, 0);
    },
    btnEdit: function btnEdit(Item) {
      this.AddNewProductDialog = true;
      this.SaveOrEdit = false;
      this.AddOrEdit = 'Edit Product';
      this.newRow = Item;
    }
  },
  mounted: function mounted() {
    this.GetShoppingList();
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"46b12186-vue-loader-template\"}!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/MainShoppingList.vue?vue&type=template&id=07975f2f&scoped=true&":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"46b12186-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/MainShoppingList.vue?vue&type=template&id=07975f2f&scoped=true& ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "v-card",
    [
      _c(
        "v-form",
        { ref: "form", attrs: { "lazy-validation": "" } },
        [
          _c(
            "v-toolbar",
            {
              staticStyle: { "box-shadow": "none", "margin-bottom": "10px" },
              attrs: { dense: "", color: "transparent" }
            },
            [
              _c(
                "v-toolbar-title",
                {
                  staticStyle: {
                    flex: "1",
                    display: "flex",
                    "justify-content": "flex-end",
                    "text-align": "center",
                    "margin-bottom": "-10px"
                  }
                },
                [
                  _c(
                    "div",
                    { staticStyle: { "margin-left": "40px" } },
                    [
                      _c(
                        "v-icon",
                        {
                          attrs: { color: "rgb(22, 58, 88)" },
                          on: { click: _vm.btnAddNewProduct }
                        },
                        [_vm._v("mdi-folder-plus")]
                      ),
                      _c("h5", [_vm._v("Add Product")])
                    ],
                    1
                  )
                ]
              )
            ],
            1
          ),
          _c("div", { staticStyle: { display: "flex" } }, [
            _c(
              "div",
              { staticStyle: { flex: "4" }, attrs: { id: "scroll" } },
              [
                _c(
                  "v-card",
                  { staticClass: "card-settings" },
                  _vm._l(_vm.Items, function(value, n) {
                    return _c("ItemCard", {
                      key: n,
                      staticStyle: { margin: "20px", display: "flex" },
                      attrs: { ItemRow: value, Favorite: true },
                      on: {
                        "btn-edit": _vm.btnEdit,
                        "btn-delete": _vm.btnDelete
                      }
                    })
                  }),
                  1
                )
              ],
              1
            ),
            _c(
              "div",
              {
                staticStyle: { flex: "1", direction: "ltr" },
                attrs: { id: "scroll" }
              },
              [
                _c("v-card", { staticClass: "card-total" }, [
                  _c("p", [
                    _vm._v("Total Product: " + _vm._s(_vm.Items.length))
                  ]),
                  _c("p", [_vm._v("Total Price: " + _vm._s(_vm.TotalPrice))])
                ])
              ],
              1
            )
          ])
        ],
        1
      ),
      _c(
        "div",
        [
          _c(
            "v-dialog",
            {
              attrs: { persistent: "", "max-width": "600px" },
              model: {
                value: _vm.AddNewProductDialog,
                callback: function($$v) {
                  _vm.AddNewProductDialog = $$v
                },
                expression: "AddNewProductDialog"
              }
            },
            [
              _c(
                "v-card",
                [
                  _c(
                    "v-form",
                    { ref: "formAddOrEdit", attrs: { "lazy-validation": "" } },
                    [
                      _c("v-card-title", [
                        _c("span", { staticClass: "text-h5" }, [
                          _vm._v(_vm._s(_vm.AddOrEdit))
                        ])
                      ]),
                      _c(
                        "v-card-text",
                        [
                          _c(
                            "v-container",
                            [
                              _c(
                                "v-row",
                                [
                                  _c(
                                    "v-col",
                                    { attrs: { sm: "6" } },
                                    [
                                      _c("v-text-field", {
                                        attrs: {
                                          rules: [_vm.rules.required],
                                          label: "Name",
                                          required: ""
                                        },
                                        model: {
                                          value: _vm.newRow.GroseryItemName,
                                          callback: function($$v) {
                                            _vm.$set(
                                              _vm.newRow,
                                              "GroseryItemName",
                                              $$v
                                            )
                                          },
                                          expression: "newRow.GroseryItemName"
                                        }
                                      })
                                    ],
                                    1
                                  ),
                                  _c(
                                    "v-col",
                                    { attrs: { sm: "6" } },
                                    [
                                      _c("v-text-field", {
                                        attrs: {
                                          rules: [_vm.rules.required],
                                          label: "Price",
                                          required: ""
                                        },
                                        on: { keypress: _vm.onlyNumber },
                                        model: {
                                          value: _vm.newRow.GroseryItemPrice,
                                          callback: function($$v) {
                                            _vm.$set(
                                              _vm.newRow,
                                              "GroseryItemPrice",
                                              $$v
                                            )
                                          },
                                          expression: "newRow.GroseryItemPrice"
                                        }
                                      })
                                    ],
                                    1
                                  )
                                ],
                                1
                              ),
                              _c(
                                "v-row",
                                [
                                  _c(
                                    "v-col",
                                    { attrs: { cols: "12" } },
                                    [
                                      _c("v-text-field", {
                                        attrs: {
                                          rules: [_vm.rules.required],
                                          label: "Decsriptoin",
                                          required: ""
                                        },
                                        model: {
                                          value: _vm.newRow.Description,
                                          callback: function($$v) {
                                            _vm.$set(
                                              _vm.newRow,
                                              "Description",
                                              $$v
                                            )
                                          },
                                          expression: "newRow.Description"
                                        }
                                      })
                                    ],
                                    1
                                  )
                                ],
                                1
                              )
                            ],
                            1
                          )
                        ],
                        1
                      ),
                      _c(
                        "v-card-actions",
                        [
                          _c("v-spacer"),
                          _c(
                            "v-btn",
                            {
                              attrs: { color: "blue darken-1", text: "" },
                              on: {
                                click: function($event) {
                                  _vm.AddNewProductDialog = false
                                }
                              }
                            },
                            [_vm._v(" Close ")]
                          ),
                          _c(
                            "v-btn",
                            {
                              directives: [
                                {
                                  name: "show",
                                  rawName: "v-show",
                                  value: _vm.SaveOrEdit,
                                  expression: "SaveOrEdit"
                                }
                              ],
                              attrs: { color: "blue darken-1", text: "" },
                              on: { click: _vm.SaveProduct }
                            },
                            [_vm._v(" Save ")]
                          ),
                          _c(
                            "v-btn",
                            {
                              directives: [
                                {
                                  name: "show",
                                  rawName: "v-show",
                                  value: !_vm.SaveOrEdit,
                                  expression: "!SaveOrEdit"
                                }
                              ],
                              attrs: { color: "blue darken-1", text: "" },
                              on: { click: _vm.EditProduct }
                            },
                            [_vm._v(" Edit ")]
                          )
                        ],
                        1
                      )
                    ],
                    1
                  )
                ],
                1
              )
            ],
            1
          )
        ],
        1
      ),
      _c(
        "v-progress-circular",
        {
          directives: [
            {
              name: "show",
              rawName: "v-show",
              value: _vm.value,
              expression: "value"
            }
          ],
          staticStyle: {
            opacity: "0.5",
            "background-color": "black",
            height: "96%",
            width: "100% !important",
            position: "fixed",
            "z-index": "999999999999999999",
            top: "0vh",
            right: "0vw"
          },
          attrs: { size: 350, width: 20, color: "primary", indeterminate: "" }
        },
        [
          _c(
            "p",
            { staticStyle: { "font-size": "30px", "font-weight": "bold" } },
            [_vm._v(" אנא המתן...... ")]
          )
        ]
      ),
      _vm.alert
        ? _c(
            "v-alert",
            {
              staticStyle: { "z-index": "999", position: "fixed", bottom: "0" },
              attrs: { prominent: "", type: _vm.msgType }
            },
            [_vm._v(_vm._s(_vm.msg))]
          )
        : _vm._e()
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ })

})
//# sourceMappingURL=app.c88ba3b95f3420747b56.hot-update.js.map
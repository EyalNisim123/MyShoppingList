webpackHotUpdate("app",{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/MainShoppingList.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--12-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/MainShoppingList.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.find-index.js */ "./node_modules/core-js/modules/es.array.find-index.js");
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.splice.js */ "./node_modules/core-js/modules/es.array.splice.js");
/* harmony import */ var core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_splice_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ItemCard_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./ItemCard.vue */ "./src/components/ItemCard.vue");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_3__);


//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


var BackendUrl = window.location.origin;
var api = axios__WEBPACK_IMPORTED_MODULE_3___default.a.create({
  baseURL: BackendUrl,
  headers: {
    'Content-Type': 'application/json'
  }
});
/* harmony default export */ __webpack_exports__["default"] = ({
  name: "MainShoppingList",
  components: {
    ItemCard: _ItemCard_vue__WEBPACK_IMPORTED_MODULE_2__["default"]
  },
  data: function data() {
    return {
      Items: [],
      newRow: {},
      TotalPrice: 0,
      value: false,
      SaveOrEdit: false,
      AddNewProductDialog: false,
      msgType: null,
      alert: false,
      AddOrEdit: 'New Product',
      msg: '',
      rules: {
        required: function required(v) {
          return !!v || 'Required';
        }
      }
    };
  },
  watch: {
    Items: function Items() {
      this.SumOfProduct();
    }
  },
  methods: {
    SumOfProduct: function SumOfProduct() {
      if (this.Items.length > 0) {
        for (var i = 0; i < this.Items.length; i++) {
          this.TotalPrice = parseFloat(this.TotalPrice) + parseFloat(this.Items[i].GroseryItemPrice);
        }
      } else {
        return 0;
      }
    },
    GetShoppingList: function GetShoppingList() {
      var _this = this;

      this.value = true;
      api.post("/GetShoppingList").then(function (response) {
        if (response.data) {
          _this.Items = response.data.ShoppingListItem;
          _this.value = false;
        }
      }, function (err) {
        this.value = false;
        this.ShowMessage('Error', 'error');
        console.log(err);
      });
    },
    btnAddNewProduct: function btnAddNewProduct() {
      this.AddNewProductDialog = true;
      this.SaveOrEdit = true;
      this.AddOrEdit = 'New Product';
    },
    SaveProduct: function SaveProduct() {
      if (this.$refs.formAddOrEdit.validate()) {
        this.newRow.GroseryItemId = this.Items.length + 1;
        this.newRow.GroseryPriceId = 'NIS';
        this.newRow.GroseryItemPrice = parseFloat(this.newRow.GroseryItemPrice);
        this.Items.push(this.newRow);
        this.AddNewProductDialog = false;
      } else {
        this.ShowMessage('Required Fields', 'error');
      }
    },
    EditProduct: function EditProduct() {
      var x = 1;
    },
    ShowMessage: function ShowMessage(msg, type) {
      var _this2 = this;

      this.msgType = msg;
      this.alert = true;
      this.msg = type;
      setTimeout(function () {
        _this2.alert = false;
      }, 1500);
    },
    onlyNumber: function onlyNumber(event) {
      var keyCode = event.keyCode;

      if (keyCode >= 48 && keyCode <= 57 || keyCode == 44) {
        return;
      }

      event.preventDefault();
    },
    btnDelete: function btnDelete(id) {
      var index = this.Items.findIndex(function (e) {
        return e.GroseryItemId === id;
      });
      this.Items.splice(index, 1);
      this.ItemsTmp = this.Items;
      this.Items = [];
      this.Items = this.ItemsTmp;
      this.SumOfProduct();
    },
    UpdateShoppingList: function UpdateShoppingList() {}
  },
  mounted: function mounted() {
    this.GetShoppingList();
  }
});

/***/ })

})
//# sourceMappingURL=app.44bc8a0f39db6cef9424.hot-update.js.map
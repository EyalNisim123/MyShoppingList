webpackHotUpdate("app",{

/***/ "./src/router/index.js":
/*!*****************************!*\
  !*** ./src/router/index.js ***!
  \*****************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ "./node_modules/vue/dist/vue.runtime.esm.js");
/* harmony import */ var vue_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vue-router */ "./node_modules/vue-router/dist/vue-router.esm.js");
/* harmony import */ var _components_MainShoppingList__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../components/MainShoppingList */ "./src/components/MainShoppingList.vue");



vue__WEBPACK_IMPORTED_MODULE_0__["default"].use(vue_router__WEBPACK_IMPORTED_MODULE_1__["default"]);
var routes = [{
  path: '/',
  name: 'MainShoppingList',
  component: _components_MainShoppingList__WEBPACK_IMPORTED_MODULE_2__["default"]
}];
var router = new vue_router__WEBPACK_IMPORTED_MODULE_1__["default"]({
  routes: routes
});
/* harmony default export */ __webpack_exports__["default"] = (router);

/***/ })

})
//# sourceMappingURL=app.316b2d8e008cae95aba4.hot-update.js.map
webpackHotUpdate("app",{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/MainShoppingList.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--12-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/MainShoppingList.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ItemCard_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ItemCard.vue */ "./src/components/ItemCard.vue");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


var BackendUrl = window.location.origin;
var api = axios__WEBPACK_IMPORTED_MODULE_1___default.a.create({
  baseURL: BackendUrl,
  headers: {
    'Content-Type': 'application/json'
  }
});
/* harmony default export */ __webpack_exports__["default"] = ({
  name: "MainShoppingList",
  components: {
    ItemCard: _ItemCard_vue__WEBPACK_IMPORTED_MODULE_0__["default"]
  },
  data: function data() {
    return {
      Items: [],
      TotalPrice: 0,
      value: false,
      msgType: null,
      alert: false,
      msg: ''
    };
  },
  watch: {
    Items: function Items() {
      this.SumOfProduct();
    }
  },
  methods: {
    SumOfProduct: function SumOfProduct() {
      if (this.Items.length > 0) {
        for (var i = 0; i < this.Items.length; i++) {
          this.TotalPrice = parseFloat(this.TotalPrice) + parseFloat(this.Items[i].GroseryItemPrice);
        }
      } else {
        return 0;
      }
    },
    GetShoppingList: function GetShoppingList() {
      var _this = this;

      this.value = true;
      api.post("/GetShoppingList").then(function (response) {
        if (response.data) {
          _this.Items = response.data.ShoppingListItem;

          _this.SumOfProduct();

          _this.value = false;
        }
      }, function (err) {
        var _this2 = this;

        this.value = false;
        this.msgType = 'error';
        this.alert = true;
        this.msg = 'Error';
        setTimeout(function () {
          _this2.alert = false;
        }, 1500);
        console.log(err);
      });
    },
    btnAAddNewProduct: function btnAAddNewProduct() {
      var x = 1;
    }
  },
  mounted: function mounted() {
    this.GetShoppingList();
  }
});

/***/ })

})
//# sourceMappingURL=app.bd3b320f0a890da6da8a.hot-update.js.map
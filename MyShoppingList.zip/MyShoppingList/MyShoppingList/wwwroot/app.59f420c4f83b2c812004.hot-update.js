webpackHotUpdate("app",{

/***/ "./node_modules/cache-loader/dist/cjs.js?!./node_modules/babel-loader/lib/index.js!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/MainShoppingList.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js??ref--12-0!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/MainShoppingList.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//import ItemCard from './ItemCard.vue';

var BackendUrl = window.location.origin;
var api = axios__WEBPACK_IMPORTED_MODULE_0___default.a.create({
  baseURL: BackendUrl,
  headers: {
    'Content-Type': 'application/json'
  }
});
/* harmony default export */ __webpack_exports__["default"] = ({
  name: "MainShoppingList",
  components: {
    ItemCard: ItemCard
  },
  data: function data() {
    return {
      Items: [],
      value: false,
      msgType: null,
      alert: false,
      msg: ''
    };
  },
  methods: {
    onlyNumber: function onlyNumber(event) {
      var keyCode = event.keyCode;

      if (keyCode >= 48 && keyCode <= 57 || keyCode == 44 || keyCode == 39) {
        var x = 1;
      } else {
        event.preventDefault();
      }
    },
    checkLengthPrice: function checkLengthPrice(event) {
      if (this.form.AdPrice) {
        if (this.form.AdPrice.length < 6 || event.keyCode == 8) {
          var x = 1;
        } else {
          event.preventDefault();
        }
      }
    },
    GetShoppingList: function GetShoppingList() {
      var _this = this;

      this.value = true;
      api.post("/GetShoppingList").then(function (response) {
        if (response.data) {
          _this.PatsTmp = response.data;
          _this.value = false;
        }
      }, function (err) {
        var _this2 = this;

        this.value = false;
        this.msgType = 'error';
        this.alert = true;
        this.msg = 'Error';
        setTimeout(function () {
          _this2.alert = false;
        }, 1500);
        console.log(err);
      });
    }
  },
  mounted: function mounted() {
    this.GetShoppingList();
  }
});

/***/ }),

/***/ "./node_modules/cache-loader/dist/cjs.js?{\"cacheDirectory\":\"node_modules/.cache/vue-loader\",\"cacheIdentifier\":\"46b12186-vue-loader-template\"}!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/cache-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./src/components/MainShoppingList.vue?vue&type=template&id=07975f2f&scoped=true&":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"46b12186-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--0-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/MainShoppingList.vue?vue&type=template&id=07975f2f&scoped=true& ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "v-card",
    [
      _c(
        "v-form",
        { ref: "form", attrs: { "lazy-validation": "" } },
        [
          _c(
            "v-toolbar",
            {
              staticStyle: { "box-shadow": "none", "margin-bottom": "10px" },
              attrs: { dense: "", color: "transparent" }
            },
            [
              _c("v-toolbar-title", { staticStyle: { flex: "1" } }),
              _c(
                "v-toolbar-title",
                {
                  staticStyle: {
                    flex: "1",
                    "text-align": "center",
                    "font-size": "30px",
                    "font-weight": "bold"
                  }
                },
                [_vm._v("My Shopping List")]
              ),
              _c("v-toolbar-title", {
                staticStyle: {
                  flex: "1",
                  display: "flex",
                  "justify-content": "flex-end",
                  "text-align": "center",
                  "margin-bottom": "-10px"
                }
              })
            ],
            1
          )
        ],
        1
      ),
      _c(
        "v-progress-circular",
        {
          directives: [
            {
              name: "show",
              rawName: "v-show",
              value: _vm.value,
              expression: "value"
            }
          ],
          staticStyle: {
            opacity: "0.5",
            "background-color": "black",
            height: "96%",
            width: "100% !important",
            position: "fixed",
            "z-index": "999999999999999999",
            top: "0vh",
            right: "0vw"
          },
          attrs: { size: 350, width: 20, color: "primary", indeterminate: "" }
        },
        [
          _c(
            "p",
            { staticStyle: { "font-size": "30px", "font-weight": "bold" } },
            [_vm._v(" ��� ����...... ")]
          )
        ]
      ),
      _vm.alert
        ? _c(
            "v-alert",
            {
              staticStyle: { "z-index": "999", position: "fixed", bottom: "0" },
              attrs: { prominent: "", type: _vm.msgType }
            },
            [_vm._v(_vm._s(_vm.msg))]
          )
        : _vm._e()
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./src/components/MainShoppingList.vue":
/*!*********************************************!*\
  !*** ./src/components/MainShoppingList.vue ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _MainShoppingList_vue_vue_type_template_id_07975f2f_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./MainShoppingList.vue?vue&type=template&id=07975f2f&scoped=true& */ "./src/components/MainShoppingList.vue?vue&type=template&id=07975f2f&scoped=true&");
/* harmony import */ var _MainShoppingList_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./MainShoppingList.vue?vue&type=script&lang=js& */ "./src/components/MainShoppingList.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _MainShoppingList_vue_vue_type_style_index_0_id_07975f2f_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./MainShoppingList.vue?vue&type=style&index=0&id=07975f2f&scoped=true&lang=css& */ "./src/components/MainShoppingList.vue?vue&type=style&index=0&id=07975f2f&scoped=true&lang=css&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");
/* harmony import */ var _node_modules_vuetify_loader_lib_runtime_installComponents_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../node_modules/vuetify-loader/lib/runtime/installComponents.js */ "./node_modules/vuetify-loader/lib/runtime/installComponents.js");
/* harmony import */ var _node_modules_vuetify_loader_lib_runtime_installComponents_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vuetify_loader_lib_runtime_installComponents_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var vuetify_lib_components_VAlert__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! vuetify/lib/components/VAlert */ "./node_modules/vuetify/lib/components/VAlert/index.js");
/* harmony import */ var vuetify_lib_components_VCard__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! vuetify/lib/components/VCard */ "./node_modules/vuetify/lib/components/VCard/index.js");
/* harmony import */ var vuetify_lib_components_VForm__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! vuetify/lib/components/VForm */ "./node_modules/vuetify/lib/components/VForm/index.js");
/* harmony import */ var vuetify_lib_components_VProgressCircular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! vuetify/lib/components/VProgressCircular */ "./node_modules/vuetify/lib/components/VProgressCircular/index.js");
/* harmony import */ var vuetify_lib_components_VToolbar__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! vuetify/lib/components/VToolbar */ "./node_modules/vuetify/lib/components/VToolbar/index.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _MainShoppingList_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _MainShoppingList_vue_vue_type_template_id_07975f2f_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"],
  _MainShoppingList_vue_vue_type_template_id_07975f2f_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "07975f2f",
  null
  
)

/* vuetify-loader */







_node_modules_vuetify_loader_lib_runtime_installComponents_js__WEBPACK_IMPORTED_MODULE_4___default()(component, {VAlert: vuetify_lib_components_VAlert__WEBPACK_IMPORTED_MODULE_5__["VAlert"],VCard: vuetify_lib_components_VCard__WEBPACK_IMPORTED_MODULE_6__["VCard"],VForm: vuetify_lib_components_VForm__WEBPACK_IMPORTED_MODULE_7__["VForm"],VProgressCircular: vuetify_lib_components_VProgressCircular__WEBPACK_IMPORTED_MODULE_8__["VProgressCircular"],VToolbar: vuetify_lib_components_VToolbar__WEBPACK_IMPORTED_MODULE_9__["VToolbar"],VToolbarTitle: vuetify_lib_components_VToolbar__WEBPACK_IMPORTED_MODULE_9__["VToolbarTitle"]})


/* hot reload */
if (true) {
  var api = __webpack_require__(/*! ./node_modules/vue-hot-reload-api/dist/index.js */ "./node_modules/vue-hot-reload-api/dist/index.js")
  api.install(__webpack_require__(/*! vue */ "./node_modules/vue/dist/vue.runtime.esm.js"))
  if (api.compatible) {
    module.hot.accept()
    if (!api.isRecorded('07975f2f')) {
      api.createRecord('07975f2f', component.options)
    } else {
      api.reload('07975f2f', component.options)
    }
    module.hot.accept(/*! ./MainShoppingList.vue?vue&type=template&id=07975f2f&scoped=true& */ "./src/components/MainShoppingList.vue?vue&type=template&id=07975f2f&scoped=true&", function(__WEBPACK_OUTDATED_DEPENDENCIES__) { /* harmony import */ _MainShoppingList_vue_vue_type_template_id_07975f2f_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./MainShoppingList.vue?vue&type=template&id=07975f2f&scoped=true& */ "./src/components/MainShoppingList.vue?vue&type=template&id=07975f2f&scoped=true&");
(function () {
      api.rerender('07975f2f', {
        render: _MainShoppingList_vue_vue_type_template_id_07975f2f_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"],
        staticRenderFns: _MainShoppingList_vue_vue_type_template_id_07975f2f_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]
      })
    })(__WEBPACK_OUTDATED_DEPENDENCIES__); }.bind(this))
  }
}
component.options.__file = "src/components/MainShoppingList.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ })

})
//# sourceMappingURL=app.59f420c4f83b2c812004.hot-update.js.map
var HtmlWebpackPlugin = require('html-webpack-plugin')

module.exports = {
	publicPath: './',
	configureWebpack: {
		"devtool": 'source-map',
		plugins: [
			new HtmlWebpackPlugin({
				template: './src/views/_LayoutTemplate.cshtml',
				filename: '../Views/Home/Index.cshtml',
				inject: true
			}),
			new HtmlWebpackPlugin({
				template: './src/views/_LayoutTemplate.cshtml',
				filename: './artifacts/Index.cshtml',
				inject: true
			})
		]
	},
	devServer: {
		writeToDisk: true
	},
	outputDir: "../wwwroot",

	"transpileDependencies": [
		"vuetify"
	],
}
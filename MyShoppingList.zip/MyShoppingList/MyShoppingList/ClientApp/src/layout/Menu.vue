<template>
	<div style="box-shadow: rgba(0, 0, 0, 0.5) 0px 1px 5px, rgba(0, 0, 0, 0.5) 0px -1px 5px; height: 50px; background-color: #163a58; text-align: center; color: white; font-size: x-large;">
		My Shopping List
	</div>
</template>

<script>
	export default {
		name: "Menu",
		data: () => ({
			items: [
                { title: "My Shopping List", icon: "mdi-account-group-outline", route: "/" }
			]
		})
	};
</script>

<style>

	.v-icon.v-icon {
		font-size: 35px !important;
	}

	.v-list-item__icon {
		margin-left: 7px !important;
	}

</style>

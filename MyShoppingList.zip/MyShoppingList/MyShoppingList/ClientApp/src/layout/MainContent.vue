<template>
	<v-main style="display: flex; flex-direction: column;background-color: #f7f7f7; overflow-y: hidden;">
		<v-container class="containerMainContent" fluid>
			<router-view class="routerMainContect"></router-view>
		</v-container>
	</v-main>
</template>

<script>

	export default {
		name: "MainContent",
	};
</script>

<style scoped>
	.containerMainContent {
		height: 100%;
	}
    .routerMainContect{
		max-height: 88vh;
		display: flex;
		flex-direction: column;
		background-color: transparent !important;
		box-shadow: none !important;
		overflow-y: hidden;
    }
</style>
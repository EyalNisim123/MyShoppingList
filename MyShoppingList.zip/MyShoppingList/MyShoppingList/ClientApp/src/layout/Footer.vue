<template>
	<v-footer app dense dark>
		<div style="display: flex; justify-content: space-between; width: 100%">
			<div>
				<span>גרסא &nbsp;</span>
				<span>0.0.5</span>
			</div>
		</div>
	</v-footer>
</template>

<script>

	export default {
		name: "Footer"
	};

</script>
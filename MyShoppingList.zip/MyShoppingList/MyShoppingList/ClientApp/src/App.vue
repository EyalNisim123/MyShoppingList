<template>
	<v-app>
		<Menu />
		<MainContent />
		<Footer />
	</v-app>
</template>
<script>

	import Menu from "./layout/Menu";
	import MainContent from "./layout/MainContent";
	import Footer from "./layout/Footer";

	export default {
		name: "App",
		components: { MainContent, Menu, Footer }
	};
</script>
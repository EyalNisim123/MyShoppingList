﻿<template>
    <v-card>
        <v-form ref="form" lazy-validation>
            <v-toolbar dense color="transparent" style="box-shadow: none; margin-bottom: 10px;">
                <v-toolbar-title style="flex: 1; display: flex; justify-content: flex-end; text-align: center; margin-bottom: -10px;">
                    <div style="margin-left: 40px;">
                        <v-icon @click="btnAddNewProduct" color="rgb(22, 58, 88)">mdi-folder-plus</v-icon>
                        <h5>Add Product</h5>
                    </div>
                </v-toolbar-title>
            </v-toolbar>
            <div style="display: flex;">
                <div id="scroll" style="flex: 4;">
                    <v-card class="card-settings">
                        <ItemCard v-on:btn-edit="btnEdit" v-on:btn-delete="btnDelete" v-for="(value, n) in Items" v-bind:key="n" :ItemRow="value" :Favorite="true" style="margin: 20px; display: flex;" />
                    </v-card>
                </div>
                <div id="scroll" style="flex: 1; direction: ltr">
                    <v-card class="card-total">
                        <p>Total Product:  {{Items.length}}</p>
                        <p>Total Price:  {{TotalPrice}}</p>
                    </v-card>
                </div>
            </div>

        </v-form>
        <div>
            <v-dialog v-model="AddNewProductDialog"
                      persistent
                      max-width="600px">
                <v-card>
                    <v-form ref="formAddOrEdit" lazy-validation>
                        <v-card-title>
                            <span class="text-h5">{{AddOrEdit}}</span>
                        </v-card-title>
                        <v-card-text>
                            <v-container>
                                <v-row>
                                    <v-col sm="6">
                                        <v-text-field :rules="[rules.required]" v-model="newRow.GroseryItemName" label="Name" required></v-text-field>
                                    </v-col>
                                    <v-col sm="6">
                                        <v-text-field :rules="[rules.required]" @keypress="onlyNumber" v-model="newRow.GroseryItemPrice" label="Price" required></v-text-field>
                                    </v-col>
                                </v-row>
                                <v-row>
                                    <v-col cols="12">
                                        <v-text-field :rules="[rules.required]" v-model="newRow.Description" label="Decsriptoin" required></v-text-field>
                                    </v-col>
                                </v-row>
                            </v-container>
                        </v-card-text>
                        <v-card-actions>
                            <v-spacer></v-spacer>
                            <v-btn color="blue darken-1"
                                   text
                                   @click="AddNewProductDialog = false">
                                Close
                            </v-btn>
                            <v-btn color="blue darken-1"
                                   text
                                   v-show="SaveOrEdit"
                                   @click="SaveProduct">
                                Save
                            </v-btn>
                            <v-btn color="blue darken-1"
                                   text
                                   v-show="!SaveOrEdit"
                                   @click="EditProduct">
                                Edit
                            </v-btn>
                        </v-card-actions>
                    </v-form>
                </v-card>
            </v-dialog>
        </div>
        <v-progress-circular :size="350"
                             :width="20"
                             color="primary"
                             indeterminate
                             v-show="value"
                             style="opacity: 0.5; background-color: black; height: 96%; width: 100% !important; position: fixed; z-index: 999999999999999999; top: 0vh; right: 0vw;">
            <p style="font-size: 30px; font-weight: bold;"> אנא המתן...... </p>
        </v-progress-circular>
        <v-alert style="z-index: 999; position: fixed; bottom: 0;" prominent :type="msgType" v-if="alert">{{msg}}</v-alert>
    </v-card>
</template>


<script>

    import ItemCard from './ItemCard.vue';
    import axios from "axios";
    var BackendUrl = window.location.origin;
    const api = axios.create({ baseURL: BackendUrl, headers: { 'Content-Type': 'application/json' } });

    export default {
        name: "MainShoppingList",
        components: { ItemCard },
        data: () => ({
            Items: [],
            ItemsTmp: [],
            newRow: {},
            TotalPrice: 0,
            value: false,
            SaveOrEdit: false,
            AddNewProductDialog: false,
            msgType: null,
            alert: false,
            AddOrEdit: 'New Product',
            msg: '',
            rules: {
                required: v => !!v || 'Required'
            }
        }),
        watch: {
            Items: function () {
                this.SumOfProduct();
            }
        },
        methods: {
            SumOfProduct() {
                this.TotalPrice = 0;
                if (this.Items.length > 0) {
                    for (var i = 0; i < this.Items.length; i++) {
                        this.TotalPrice = parseFloat(this.TotalPrice) + parseFloat(this.Items[i].GroseryItemPrice)
                    }
                } else {
                    return 0;
                }
            },
            GetShoppingList() {
                this.value = true;
                api.post("/GetShoppingList").then((response) => {
                    if (response.data) {
                        this.Items = response.data.ShoppingListItem;
                        this.value = false;
                    }
                }, function (err) {
                    this.value = false;
                    this.ShowMessage('Error', 'error')
                    console.log(err);
                });
            },
            btnAddNewProduct() {
                this.AddNewProductDialog = true;
                this.SaveOrEdit = true;
                this.AddOrEdit = 'New Product';
                this.newRow = {};
            },
            SaveProduct() {
                if (this.$refs.formAddOrEdit.validate()) {
                    this.newRow.GroseryItemId = this.Items.length + 1;
                    this.newRow.GroseryPriceId = 'NIS'
                    this.newRow.GroseryItemPrice = parseFloat(this.newRow.GroseryItemPrice);
                    this.Items.push(this.newRow);
                    this.AddNewProductDialog = false;
                }
                else {
                    this.ShowMessage('Required Fields', 'error')
                }
            },
            EditProduct() {

                this.Items.filter(x => { return x.GroseryItemId === this.newRow.GroseryItemId })[0] = this.newRow;
                this.AddNewProductDialog = false;
                this.SumOfProduct();
            },
            ShowMessage(msg, type) {
                this.msgType = msg;
                this.alert = true;
                this.msg = type
                setTimeout(() => {
                    this.alert = false;
                }, 1500);
            },
            onlyNumber(event) {
                let keyCode = event.keyCode;
                if (keyCode >= 48 && keyCode <= 57 || keyCode == 44) {
                    return;
                }
                event.preventDefault();
            },
            btnDelete(id) {
                var vm = this;
                const index = this.Items.findIndex((e) => e.GroseryItemId === id);
                this.Items.splice(index, 1);
                this.ItemsTmp = Object.assign(this.ItemsTmp, this.Items);
                this.Items = [];
                setTimeout(function () {
                    vm.Items = vm.ItemsTmp
                    vm.SumOfProduct();
                }, 0);

            },
            btnEdit(Item) {
                this.AddNewProductDialog = true;
                this.SaveOrEdit = false;
                this.AddOrEdit = 'Edit Product';
                this.newRow = Item;
            }
        },
        mounted: function () {
            this.GetShoppingList();
        }
    };

</script>

<style>

    .card-settings {
        right: 5%;
        background-color: transparent !important;
        display: flex;
        flex-wrap: wrap;
        box-shadow: none !important;
        height: min-content;
    }
    .card-total {
        display: block;
        flex-wrap: wrap;
        margin: 20px;
        padding: 20px;
        padding-top: 5px;
        height: fit-content;
        background-color: transparent !important;
        box-shadow: 0px 3px 1px -2px rgba(0, 0, 0, 0.2), 0px 2px 2px 0px rgba(0, 0, 0, 0.14), 0px 1px 5px 0px rgba(0, 0, 0, 0.12) !important;
    }

    .v-data-table {
        max-height: 150px !important;
    }

</style>

<style scoped>

    .v-list {
        display: block !important;
    }
</style>
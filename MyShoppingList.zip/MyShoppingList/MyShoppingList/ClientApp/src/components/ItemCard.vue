﻿<template>
    <v-card elevation="8"
            width="32vw"
            outlined
            style="cursor: pointer;">
        <v-list-item>
            <v-list-item-content @click="btnOpenDetail" style="cursor: pointer; flex-direction: row;">
                <h3>{{form.GroseryItemName}}</h3>
            </v-list-item-content>
            <v-list-item-content @click="btnOpenDetail" style="cursor: pointer; flex-direction: row;">
                <h3>{{form.GroseryItemPrice}} {{form.GroseryPriceId}}</h3>
            </v-list-item-content>
            <v-icon @click="btnEdit">mdi-pencil</v-icon>
            <v-icon @click="btnDelete">mdi-delete</v-icon>
        </v-list-item>

        <div>
            <v-dialog v-model="OpenDetailDialog"
                      persistent
                      max-width="290">
                <v-card>
                    <v-card-title class="text-h5">
                        {{form.GroseryItemName}}
                    </v-card-title>
                    <v-card-text>{{form.Description}}</v-card-text>
                    <v-card-actions>
                        <v-spacer></v-spacer>
                        <v-btn color="green darken-1"
                               text
                               @click="OpenDetailDialog = false">
                            Close
                        </v-btn>
                    </v-card-actions>
                </v-card>
            </v-dialog>
        </div>

    </v-card>
</template>


<script>

    export default {
        name: "ItemCard",
        data: () => ({
            form: {},
            OpenDetailDialog: false,
        }),
        props: ['ItemRow', 'Favorite'],
       
        methods: {
            btnEdit() {
                this.$emit("btn-edit", this.form)
            },
            btnDelete() {
                this.$swal.fire({
                    title: "Delete Product",
                    text: "Are you sure you want to delete this Product?",
                    icon: "warning",
                    showCancelButton: true,
                    cancelButtonText: "No",
                    cancelButtonColor: "#d33",
                    confirmButtonColor: "DD6B55",
                    confirmButtonText: "Yes",
                }).then((res) => {
                    if (res.isConfirmed) {
                        this.$emit("btn-delete", this.form.GroseryItemId)
                    }
                });
            },
            btnOpenDetail() {
                this.OpenDetailDialog = true;
            }
        },
        mounted: function () {
            this.form = this.ItemRow;
        }
    };

</script>


<style scoped>

    .v-icon.v-icon::after {
        background-color: transparent;
    }
    .v-list-item{
        direction: ltr;
    }
    .v-list-item__content{
        padding: 0;
    }
        .v-list-item__content > * {
            line-height: 1.1;
            flex: none;
        }

</style>
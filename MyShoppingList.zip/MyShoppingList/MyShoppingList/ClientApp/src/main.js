import Vue from 'vue'
import App from './App.vue'
import vuetify from './plugins/vuetify';
import Vuetify from 'vuetify/lib'
import router from './router'
import he from 'vuetify/es5/locale/he'
import axios from 'axios'
import '@mdi/font/css/materialdesignicons.css'
import VueAxios from 'vue-axios'
import VueSweetalert2 from 'vue-sweetalert2'
import Vuex from 'vuex'


console.log(window.ITGlobalConfig);

Vue.prototype.$http = axios;

Vue.use(Vuex);
Vue.use(axios);
Vue.use(VueSweetalert2);

const store = new Vuex.Store({
	state: {
		BackendUrl: null
	},
	mutations: {
		SetBackendUrl(state, BackendUrl) {
			state.BackendUrl = BackendUrl;
		},
	}
})

Vue.config.productionTip = false

export default new Vuetify({
	rtl: true,
})
new Vue({
	vuetify,
	store: store,
	icons: {
		iconfont: 'mdi'
	},
	router,
	lang: {
		locales: { he },
		current: 'he',
	},
	render: h => h(App)
}).$mount('#app')

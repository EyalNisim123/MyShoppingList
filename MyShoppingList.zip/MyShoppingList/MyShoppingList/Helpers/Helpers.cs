﻿using Microsoft.AspNetCore.Http;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;

using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.WebSockets;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace IT_Template
{
    public static class Helpers
    {
        public static IHttpContextAccessor _accessor;
        public static IConfiguration _configuration;

        public static void SetInitElements(IHttpContextAccessor accesor, IConfiguration configuration)
        {
            _configuration = configuration;
            _accessor = accesor;
        }

        // כתיבת שגיאות לשרת הלוגים
        public static void WriteErorr(string domain, string msg, string stack)
        {
            try
            {
                //Log log = new Log();
                //log.AppName = "ShoppingList";
                //log.Message = msg;
                //log.StackTrace = stack;
                //log.domain = domain;
            }
            catch (Exception)
            {

            }
        }

    }

}